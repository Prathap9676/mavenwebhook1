package com.fooddelivery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/food")
@CrossOrigin
public class FoodItemController {

    @Autowired
    private FoodItemRepository foodRepo;

    @GetMapping
    public List<FoodItem> getAll() {
        return foodRepo.findAll();
    }

    @PostMapping
    public FoodItem addItem(@RequestBody FoodItem item) {
        return foodRepo.save(item);
    }
}